require("dotenv").config();
const express = require("express");

const authorsRoutes = require("./routes/authors");
const bookRoutes = require("./routes/books");

const app = express();
app.use(express.json());

app.use("/authors", authorsRoutes);
app.use("/books", bookRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log('Server is running on 3000');
});