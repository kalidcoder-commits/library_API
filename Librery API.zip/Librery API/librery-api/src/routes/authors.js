const express = require("express");
const router = express.Router();
const db = require("../db");

// GET all authors
router.get("/", async (req, res) => {
    try {
        // const [rows] = await db.query("SELECT * FROM authors");
        const [rows] = await db.query("SELECT * FROM authors WHERE is_active = true");
        res.json(rows);
    } catch (err) {
        res.status(500).json({ message: "authors is working"});
    }
});

// አንድን ደራሲ በ ID ብቻ ለመጥራት
router.get("/:id", async (req, res) => {
    const authorId = req.params.id;
    try {
        // 'is_active' የሚለውን ቃል እዚህ ጋር እንዳትጨምር!
        const [rows] = await db.query("SELECT author_id, name, bio, country FROM authors WHERE author_id = ?", [authorId]);
        
        if (rows.length === 0) {
            return res.status(404).json({ message: "ደራሲው አልተገኘም!" });
        }
        
        res.json(rows[0]);
    } catch (err) {
        res.status(500).json({ error: "የዳታቤዝ ስህተት: " + err.message });
    }
});


// ደራሲን በ ID "ማጥፋት" (Soft Delete)
router.delete("/:id", async (req, res) => {
    const authorId = req.params.id;
    try {
        // ከመሰረዝ (DELETE) ይልቅ ማሻሻል (UPDATE)
        const [result] = await db.query(
            "UPDATE authors SET is_active = false WHERE author_id = ?", 
            [authorId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "ደራሲው አልተገኘም" });
        }

        res.json({ message: "ደራሲው ከዝርዝር ላይ ተወግዷል!" });
    } catch (err) {
        res.status(500).json({ error: "የዳታቤዝ ስህተት: " + err.message });
    }
});

router.post("/", async (req, res) => {
    const { name, bio, country } = req.body;

    if (!name) {
        return res.status(400).json({ message: "Name is required" });
    }

    try {
        const [result] = await db.query(
            "INSERT INTO authors (name, bio, country) VALUES (?, ?, ?)",
            [name, bio, country]
        );
        res.status(201).json({ id: result.insertId, message: "Author added successfully" });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Database error" });
    }
});



// የመጽሐፍ መረጃን ለማሻሻል (Update book)
router.put("/:id", async (req, res) => {
    const bookId = req.params.id;
    const { title, genre, published_year, is_available } = req.body;

    try {
        const [result] = await db.query(
            "UPDATE books SET title = ?, genre = ?, published_year = ?, is_available = ? WHERE book_id = ?",
            [title, genre, published_year, is_available, bookId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "ሊታደስ የሚችል መጽሐፍ አልተገኘም!" });
        }

        res.json({ message: "መጽሐፉ በትክክል ታድሷል (Updated)!" });
    } catch (err) {
        res.status(500).json({ error: "የዳታቤዝ ስህተት: " + err.message });
    }
});



module.exports = router;