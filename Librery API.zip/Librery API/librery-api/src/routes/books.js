const express = require("express");
const router = express.Router();
const db = require("../db");

router.post("/", async (req, res) => {
  const currentYear = new Date().getFullYear(); // 2026 ያመጣል
    if (published_year > currentYear) {
        return res.status(400).json({ message: "ስህተት: የታተመበት ዓመት ወደፊት ሊሆን አይችልም!" });
    }
  try {
    const { title, genre, published_year, author_id } = req.body;
              // ... previous code

        if (!title || !author_id) {
          return res.status(400).json({ message: "Title and author_id required" });
        }

        // --- Level Up Rule ---
        const currentYear = new Date().getFullYear();
        const year = Number(published_year);   // ensure it's a number

        if (year > currentYear) {
          return res
            .status(400)
            .json({ message: "የታተመበት ዓመት ከዛሬ ሊበልጥ አይችልም!" });
        }

        // -----------------------------------------------

        await db.query(
          "INSERT INTO books (title, genre, published_year, author_id) VALUES (?, ?, ?, ?)",
          [title, genre, year, author_id]
        );

        // ... continue remaining code

    if (!title || !author_id) {
      return res.status(400).json({ message: "Title and author_id required" });
    }

    await db.query(
      "INSERT INTO books (title, genre, published_year, author_id) VALUES (?, ?, ?, ?)",
      [title, genre, published_year, author_id]
    );

    res.status(201).json({ message: "Book added" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
});




router.get("/", async (req, res) => {
    try {
        // Space መኖሩን አረጋግጥ: "ON books.author_id"
        const sql = 
           ` SELECT books.*, authors.name AS author_name 
            FROM books 
            JOIN authors ON books.author_id = authors.author_id
        `
        const [rows] = await db.query(sql);
        res.json(rows); 
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server error", error: err.message });
    }
});




router.get("/", async (req, res) => {
    const genreFilter = req.query.genre; 
    try {
        let sql = "SELECT * FROM books";
        let params = [];

        if (genreFilter) {
            sql += " WHERE genre = ?";
            params.push(genreFilter);
        }

        const [rows] = await db.query(sql, params);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// router.get("/:id", async (req, res) => {
//   const [rows] = await db.query(
//     "SELECT * FROM books WHERE book_id = ?",
//     [req.params.id]
//   );
//   res.json(rows[0]);
// });

// router.put("/:id", async (req, res) => {
//   const { is_available } = req.body;
//   await db.query(
//     "UPDATE books SET is_available = ? WHERE book_id = ?",
//     [is_available, req.params.id]
//   );
//   res.json({ message: "Book updated" });
// });




// መጽሐፍ ለማጥፋት
router.delete("/:id", async (req, res) => {
    const { id } = req.params;
    try {
        // "book_id" የሚለው ስም በ MySQL ውስጥ ካለው ጋር አንድ መሆኑን አረጋግጥ
        const [result] = await db.query("DELETE FROM books WHERE book_id = ?", [id]);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "መጽሐፉ አልተገኘም!" });
        }
        
        res.json({ message: "መጽሐፉ በትክክል ጠፍቷል!" });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});








router.post("/", async (req, res) => {
    const { title, genre, published_year, author_id } = req.body;

    // የግድ የሚያስፈልጉ መረጃዎች መኖራቸውን ማረጋገጥ
    if (!title || !author_id) {
        return res.status(400).json({ message: "Title and Author ID are required!" });
    }

    try {
        const [result] = await db.query(
            "INSERT INTO books (title, genre, published_year, author_id) VALUES (?, ?, ?, ?)",
            [title, genre, published_year, author_id]
        );
        res.status(201).json({ 
            message: "መጽሐፉ በትክክል ተመዝግቧል!", 
            book_id: result.insertId 
        });
    } catch (err) {
        // የ FOREIGN KEY ስህተት ካለ (ለምሳሌ የሌለ author_id ቢሰጠው) እዚህ ይያዛል
        res.status(500).json({ error: "የዳታቤዝ ስህተት: " + err.message });
    }
});


router.get("/", async (req, res) => {
    try {
        const [rows] = await db.query(
            `ELECT books.*, authors.name AS author_name 
            FROM books 
            JOIN authors ON books.author_id = authors.author_id
        `)
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


// መጽሐፍን በ ID ለማጥፋት (Permanently remove a book)
router.delete("/:id", async (req, res) => {
    const bookId = req.params.id;
    try {
        const [result] = await db.query("DELETE FROM books WHERE book_id = ?", [bookId]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "ሊጠፋ የሚችል መጽሐፍ አልተገኘም!" });
        }

        res.json({ message: "መጽሐፉ ከዳታቤዝ በትክክል ተሰርዟል!" });
    } catch (err) {
        res.status(500).json({ error: "የዳታቤዝ ስህተት: " + err.message });
    }
});



router.post("/", async (req, res) => {
  const { title, genre, published_year, author_id } = req.body;
  
  const currentYear = new Date().getFullYear();

  if (!title || !author_id) {
    return res.status(400).json({ 
      message: "ርዕስ እና የደራሲ መታወቂያ የግድ ያስፈልጋሉ!" 
    });
  }

  // ensure published_year is a number (important)
  const year = Number(published_year);

  if (year > currentYear) {
    return res.status(400).json({ 
      message: `የታተመበት ዓመት ከ ${currentYear} መብለጥ የለበትም!` 
    });
  }

  try {
    const [result] = await db.query(
      "INSERT INTO books (title, genre, published_year, author_id) VALUES (?, ?, ?, ?)",
      [title, genre, year, author_id]
    );

    res.status(201).json({ 
      message: "መጽሐፉ በትክክል ተመዝግቧል!" 
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});







module.exports = router;
